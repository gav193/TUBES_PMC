#include <windows.h>
#include "main.h"
#include "functions.c"

// Constants for button IDs
#define IDD_DIALOG 100
#define BUTTON1_ID 101
#define BUTTON2_ID 102
#define BUTTON3_ID 103
#define BUTTON4_ID 104
#define BUTTON5_ID 105
#define BUTTON6_ID 106
#define BACK_BUTTON_ID 107
#define CARI_BUTTON_ID 108
#define TAMBAH_BUTTON_ID 109
#define UPDATE_BUTTON_ID 110
#define DELETE_BUTTON_ID 111
#define CONFIRM_BUTTON_ID 112
#define EDIT_NAME_ID 201
#define EDIT_ADDRESS_ID 202
#define EDIT_CITY_ID 203
#define EDIT_BIRTHPLACE_ID 204
#define EDIT_BIRTHDATE_ID 205
#define EDIT_AGE_ID 206
#define EDIT_BPJS_ID 207
#define LABEL_NAME 208
#define LABEL_ADDRESS 209
#define LABEL_CITY 210
#define LABEL_BIRTH_PLACE 211 
#define LABEL_BIRTH_DATE 212
#define LABEL_AGE 213
#define LABEL_BPJS 214 
#define CONFIRM_BUTTON2_ID 215


const char CLASS_NAME[] = "Sample Window Class";
char message[256] = "Click a button";
HBRUSH hBrushBackground; // Handle to the background brush
// Forward declarations
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void updateMessage(HWND hwnd, const char *newMessage);
void showInitialButtons(HWND hwnd, BOOL show);
void showDataPasienButtons(HWND hwnd, BOOL show);
//void processInput(HWND hwnd);
void processAddPatient(HWND hwnd);
void processSearchPatient(HWND hwnd);
void processUpdatePatient(HWND hwnd);
void processDeletePatient(HWND hwnd);

HWND hButton1, hButton2, hButton3, hButton4, hButton5, hButton6, hBackButton, hConfirmButton;
HWND hCariButton, hTambahButton, hUpdateButton, hDeleteButton;
HWND hEditInput; // Handle to the input edit control
HWND hEditName, hEditAddress, hEditCity, hEditBirthPlace, hEditBirthDate, hEditAge, hEditBPJS, hConfirmButton,hConfirmButton2;
HWND hLabelName, hLabelAddress, hLabelCity, hLabelBirthPlace, hLabelBirthDate, hLabelAge, hLabelBPJS;
Data data = {NULL, NULL, NULL};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    parse("satu.csv", &data);
    parse("dua.csv", &data);
    parse("tiga.csv", &data);

    WNDCLASS wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hbrBackground = CreateSolidBrush(RGB(173, 216, 230)); // Light blue background color
        
    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(
        0,
        CLASS_NAME,
        "Program Administrasi Klinik X",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 960, 600,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (hwnd == NULL) {
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);

    // Create initial buttons
    hButton1 = CreateWindow("BUTTON", "Data Pasien", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                            280, 20, 400, 30, hwnd, (HMENU) BUTTON1_ID, hInstance, NULL);
    hButton2 = CreateWindow("BUTTON", "Data Riwayat", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                            280, 60, 400, 30, hwnd, (HMENU) BUTTON2_ID, hInstance, NULL);
    hButton3 = CreateWindow("BUTTON", "Informasi Pasien dan Riwayat Medis", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                            280, 100, 400, 30, hwnd, (HMENU) BUTTON3_ID, hInstance, NULL);
    hButton4 = CreateWindow("BUTTON", "Informasi Pendapatan", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                            280, 140, 400, 30, hwnd, (HMENU) BUTTON4_ID, hInstance, NULL);
    hButton5 = CreateWindow("BUTTON", "Informasi Penyakit Pasien", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                            280, 180, 400, 30, hwnd, (HMENU) BUTTON5_ID, hInstance, NULL);
    hButton6 = CreateWindow("BUTTON", "Informasi Kontrol", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                            280, 220, 400, 30, hwnd, (HMENU) BUTTON6_ID, hInstance, NULL);
    hBackButton = CreateWindow("BUTTON", "Back", WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
                               820, 20, 100, 30, hwnd, (HMENU) BACK_BUTTON_ID, hInstance, NULL);
    ShowWindow(hBackButton, SW_HIDE);  // Hide the back button initially

    // Create Data Pasien buttons (initially hidden)
    hCariButton = CreateWindow("BUTTON", "Cari Pasien Berdasarkan ID", WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
                               280, 20, 400, 30, hwnd, (HMENU) CARI_BUTTON_ID, hInstance, NULL);
    hTambahButton = CreateWindow("BUTTON", "Tambah Pasien Baru", WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
                                 280, 60, 400, 30, hwnd, (HMENU) TAMBAH_BUTTON_ID, hInstance, NULL);
    hUpdateButton = CreateWindow("BUTTON", "Update Data Pasien", WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
                                 280, 100, 400, 30, hwnd, (HMENU) UPDATE_BUTTON_ID, hInstance, NULL);
    hDeleteButton = CreateWindow("BUTTON", "Delete Pasien", WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
                                 280, 140, 400, 30, hwnd, (HMENU) DELETE_BUTTON_ID, hInstance, NULL);

    // Create Confirm button (initially hidden)
    hConfirmButton = CreateWindow("BUTTON", "Confirm", WS_TABSTOP | WS_CHILD | BS_DEFPUSHBUTTON,
                                   490, 60, 100, 20, hwnd, (HMENU) CONFIRM_BUTTON_ID, hInstance, NULL);
    ShowWindow(hConfirmButton, SW_HIDE);
    MSG msg = {0};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}

char strIN[256];

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
        case WM_DESTROY:
            DeleteObject(hBrushBackground);
            PostQuitMessage(0);
            return 0;
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case BUTTON1_ID:
                    updateMessage(hwnd, "Data Pasien Selected");
                    showInitialButtons(hwnd, FALSE);
                    showDataPasienButtons(hwnd, TRUE);
                    break;
                case CARI_BUTTON_ID:
                    // Show an input edit control for entering ID
                    showDataPasienButtons(hwnd, FALSE);
                    hEditInput = CreateWindow("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER,
                                              280, 60, 200, 20, hwnd, NULL, NULL, NULL);
                    // Show the confirm button
                    ShowWindow(hConfirmButton, SW_SHOW);
                    break;
                case TAMBAH_BUTTON_ID:
                    // Hide other buttons and show input fields and confirm button
                    showDataPasienButtons(hwnd, FALSE);
                    hEditName = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 20, 200, 20, hwnd, (HMENU)EDIT_NAME_ID, GetModuleHandle(NULL), NULL);
                    hEditAddress = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 50, 200, 20, hwnd, (HMENU)EDIT_ADDRESS_ID, GetModuleHandle(NULL), NULL);
                    hEditCity = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 80, 200, 20, hwnd, (HMENU)EDIT_CITY_ID, GetModuleHandle(NULL), NULL);
                    hEditBirthPlace = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 110, 200, 20, hwnd, (HMENU)EDIT_BIRTHPLACE_ID, GetModuleHandle(NULL), NULL);
                    hEditBirthDate = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 140, 200, 20, hwnd, (HMENU)EDIT_BIRTHDATE_ID, GetModuleHandle(NULL), NULL);
                    hEditAge = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 170, 200, 20, hwnd, (HMENU)EDIT_AGE_ID, GetModuleHandle(NULL), NULL);
                    hEditBPJS = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE, 280, 200, 200, 20, hwnd, (HMENU)EDIT_BPJS_ID, GetModuleHandle(NULL), NULL);
                    hConfirmButton2 = CreateWindow("BUTTON", "Confirm", WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 280, 230, 100, 30, hwnd, (HMENU)CONFIRM_BUTTON2_ID, GetModuleHandle(NULL), NULL);
                    hLabelName = CreateWindow("STATIC", "Nama             : ", WS_CHILD | WS_VISIBLE, 140, 20, 100, 20, hwnd, (HMENU)LABEL_NAME,GetModuleHandle(NULL),NULL);
                    hLabelAddress = CreateWindow("STATIC", "Alamat tinggal: ", WS_CHILD | WS_VISIBLE, 140, 50, 100, 20, hwnd, (HMENU)LABEL_ADDRESS,GetModuleHandle(NULL),NULL);
                    hLabelCity = CreateWindow("STATIC",    "Kota Domisili : ", WS_CHILD | WS_VISIBLE, 140, 80, 100, 20, hwnd, (HMENU)LABEL_CITY,GetModuleHandle(NULL),NULL);
                    hLabelBirthPlace = CreateWindow("STATIC", "Tempat Lahir  : ", WS_CHILD | WS_VISIBLE, 140, 110, 100, 20, hwnd, (HMENU)LABEL_BIRTH_PLACE,GetModuleHandle(NULL),NULL);
                    hLabelBirthDate= CreateWindow("STATIC", "Tanggal Lahir : ", WS_CHILD | WS_VISIBLE, 140, 140, 100, 20, hwnd, (HMENU)LABEL_BIRTH_DATE,GetModuleHandle(NULL),NULL);
                    hLabelAge= CreateWindow("STATIC", "Umur             : ", WS_CHILD | WS_VISIBLE, 140, 170, 100, 20, hwnd, (HMENU)LABEL_AGE,GetModuleHandle(NULL),NULL);
                    hLabelBPJS= CreateWindow("STATIC", "BPJS             : ", WS_CHILD | WS_VISIBLE, 140, 200, 100, 20, hwnd, (HMENU)LABEL_BPJS ,GetModuleHandle(NULL),NULL);
                    break;
                case CONFIRM_BUTTON_ID:
                    processSearchPatient(hwnd);
                    //processAddPatient(hwnd);
                    break;
                case CONFIRM_BUTTON2_ID:
                    //processSearchPatient(hwnd);
                    processAddPatient(hwnd);
                    break;
                case BACK_BUTTON_ID:
                    updateMessage(hwnd, "Click a button");
                    showDataPasienButtons(hwnd, FALSE);
                    showInitialButtons(hwnd, TRUE);
                    DestroyWindow(hEditInput); // Destroy the input edit control
                    DestroyWindow(hEditName);
                    DestroyWindow(hEditAddress);
                    DestroyWindow(hEditCity);
                    DestroyWindow(hEditBirthPlace);
                    DestroyWindow(hEditBirthDate);
                    DestroyWindow(hEditAge);
                    DestroyWindow(hEditBPJS);
                    DestroyWindow(hLabelName);
                    DestroyWindow(hLabelAddress);
                    DestroyWindow(hLabelCity);
                    DestroyWindow(hLabelBirthPlace);
                    DestroyWindow(hLabelBirthDate);
                    DestroyWindow(hLabelAge);
                    DestroyWindow(hLabelBPJS);
                    ShowWindow(hConfirmButton2,SW_HIDE);
                    ShowWindow(hConfirmButton, SW_HIDE); // Hide the confirm button
                    break;
            }
            return 0;
        case WM_CREATE: {
            // Set the background brush
            hBrushBackground = CreateSolidBrush(RGB(173, 216, 230));
            return 0;
        }
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            // Create a compatible DC for double buffering
            HDC hdcBuffer = CreateCompatibleDC(hdc);
            HBITMAP hBitmap = CreateCompatibleBitmap(hdc, 960, 600);
            HBITMAP hBitmapOld = (HBITMAP)SelectObject(hdcBuffer, hBitmap);

            // Draw the background
            RECT rect;
            GetClientRect(hwnd, &rect);
            FillRect(hdcBuffer, &rect, hBrushBackground);

            // Draw the message text
            SetTextColor(hdcBuffer, RGB(0, 0, 0)); // Black text color
            SetBkMode(hdcBuffer, TRANSPARENT); // Transparent background
            HFONT hFont = CreateFont(17, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                                    OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                                    DEFAULT_PITCH | FF_SWISS, "Arial");
            HFONT hFontOld = (HFONT)SelectObject(hdcBuffer, hFont);
            DrawText(hdcBuffer, message, -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

            // Copy the buffer to the window
            BitBlt(hdc, 0, 0, 960, 600, hdcBuffer, 0, 0, SRCCOPY);

            // Clean up
            SelectObject(hdcBuffer, hBitmapOld);
            DeleteObject(hBitmap);
            SelectObject(hdcBuffer, hFontOld);
            DeleteObject(hFont);
            DeleteDC(hdcBuffer);

            EndPaint(hwnd, &ps);
            return 0;
        }
        case WM_ERASEBKGND: {
            HDC hdc = (HDC)wParam;
            RECT rect;
            GetClientRect(hwnd, &rect);
            FillRect(hdc, &rect, hBrushBackground);
            return 1; // Indicates that the background has been erased by the application and should not be erased again by the system
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

void updateMessage(HWND hwnd, const char *newMessage) {
    strncpy(message, newMessage, sizeof(message) - 1);
    message[sizeof(message) - 1] = '\0';
    InvalidateRect(hwnd, NULL, TRUE);
}

void showInitialButtons(HWND hwnd, BOOL show) {
    int nCmdShow = show ? SW_SHOW : SW_HIDE;
    ShowWindow(hButton1, nCmdShow);
    ShowWindow(hButton2, nCmdShow);
    ShowWindow(hButton3, nCmdShow);
    ShowWindow(hButton4, nCmdShow);
    ShowWindow(hButton5, nCmdShow);
    ShowWindow(hButton6, nCmdShow);
    ShowWindow(hBackButton, show ? SW_HIDE : SW_SHOW);
}

void showDataPasienButtons(HWND hwnd, BOOL show) {
    int nCmdShow = show ? SW_SHOW : SW_HIDE;
    ShowWindow(hCariButton, nCmdShow);
    ShowWindow(hTambahButton, nCmdShow);
    ShowWindow(hUpdateButton, nCmdShow);
    ShowWindow(hDeleteButton, nCmdShow);
}

// void processInput(HWND hwnd) {
//     char strIN[256];
//     GetWindowText(hEditInput, strIN, sizeof(strIN));
//     MessageBox(hwnd, strIN, "Input Text", MB_OK | MB_ICONINFORMATION);
//     DestroyWindow(hEditInput); // Destroy the input edit control
//     ShowWindow(hConfirmButton, SW_HIDE); // Hide the confirm button
// }

void processSearchPatient(HWND hwnd) {
    // Call function from pmc.c to search for a patient
    char strIN[256];
    char strOUT[4096];
    int found=0;
    GetWindowText(hEditInput, strIN, sizeof(strIN));
    search(&data,strIN, strOUT, &found);
    if (found == 0) {
        updateMessage(hwnd, "No patient data found.");
    } else {
        updateMessage(hwnd, strOUT);
    }
}
void processAddPatient(HWND hwnd) {
    char name[256], address[256], city[256], birthPlace[256], birthDate[256], bpjs[256];
    int age;
    char strOUT[4096];
    
    GetWindowText(hEditName, name, sizeof(name));
    GetWindowText(hEditAddress, address, sizeof(address));
    GetWindowText(hEditCity, city, sizeof(city));
    GetWindowText(hEditBirthPlace, birthPlace, sizeof(birthPlace));
    GetWindowText(hEditBirthDate, birthDate, sizeof(birthDate));
    GetWindowText(hEditAge, strOUT, sizeof(strOUT));
    age = atoi(strOUT);
    GetWindowText(hEditBPJS, bpjs, sizeof(bpjs));
    strcpy(data.satu->nama,name);
    strcpy(data.satu->alamat,address);
    strcpy(data.satu->kota,city);
    strcpy(data.satu->loc_lahir,birthPlace);
    strcpy(data.satu->tgl_lahir,birthDate);
    data.satu->umur = age;
    strcpy(data.satu->bpjs, bpjs);
    insertEnd(&data, strOUT);
    updateMessage(hwnd, strOUT);  // Display result message
}
void processUpdatePatient(HWND hwnd) {
    // Call function from pmc.c to update a patient
    //updatePatient();
    MessageBox(hwnd, "Update patient functionality here!", "Update Patient", MB_OK | MB_ICONINFORMATION);
}

void processDeletePatient(HWND hwnd) {
    // Call function from pmc.c to delete a patient
    //deletePatient();
    MessageBox(hwnd, "Delete patient functionality here!", "Delete Patient", MB_OK | MB_ICONINFORMATION);
}